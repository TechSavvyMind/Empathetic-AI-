# ===============================================================
# CLEAN & STABLE app.py FOR CHATBOT + FAQ + DIRECT RESPONSES
# ===============================================================

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
import os
from uuid import uuid4
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

# Import orchestrator
from Orchestrator import orchestrator_app
from langchain_core.messages import HumanMessage, AIMessage

# Import FAQ + Direct response handlers
from Direct_response.pre_framed_questions import get_faq_list, get_preframed_response  # :contentReference[oaicite:0]{index=0}
from Direct_response.direct_question_and_answers import get_direct_response              # :contentReference[oaicite:1]{index=1}

# ===============================================================
# INITIAL SETUP
# ===============================================================

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.urandom(32)

DB_NAME = "./Database/NextGen1.db"

# ===============================================================
# DB HELPERS
# ===============================================================

def init_db():
    """
    Ensures DB & user table exists (with customer_id!) + default admin.
    Runs before every request.
    """
    if not os.path.exists(DB_NAME):
        os.makedirs("./Database", exist_ok=True)

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()

    # IMPORTANT: customer_id added so chatbot can work
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT NOT NULL,
            password TEXT NOT NULL,
            customer_id INTEGER DEFAULT 1
        );
    """)

    # Create default admin if not exists
    admin_pass = generate_password_hash("admin")
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password, customer_id) VALUES (?, ?, ?, ?)",
            ("admin", "admin@telia.com", admin_pass, 1)
        )
        print("Default admin created.")
    except sqlite3.IntegrityError:
        pass

    conn.commit()
    conn.close()


def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

# ===============================================================
# DECORATORS
# ===============================================================

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("You need to log in first.", "error")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

# ===============================================================
# PRE-REQUEST INITIALIZATION
# ===============================================================

@app.before_request
def before_request():
    init_db()

# ===============================================================
# ROUTES
# ===============================================================

@app.route("/")
def index():
    return render_template(
        "index.html",
        username=session.get("username"),
        customer_id=session.get("customer_id"),
        chat_session_id=session.get("chat_session_id"),
    )

# -------------------- LOGIN -----------------------

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()

        if not user:
            flash("Invalid username or password", "error")
            return redirect(url_for("login"))

        if check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["customer_id"] = user["customer_id"]  # NOW FIXED
            session["chat_session_id"] = str(uuid4())
            session["chat_history"] = []
            flash(f"Welcome back, {user['username']}!", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid username or password", "error")
        return redirect(url_for("login"))

    return render_template("login.html")

# -------------------- REGISTER -----------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":

        username = request.form["username"]
        email = request.form["email"]
        password = request.form["password"]
        confirm = request.form["confirm_password"]

        if password != confirm:
            flash("Passwords do not match!", "error")
            return redirect(url_for("register"))

        hashed = generate_password_hash(password)

        try:
            conn = get_db_connection()
            conn.execute(
                "INSERT INTO users (username, email, password, customer_id) VALUES (?, ?, ?, ?)",
                (username, email, hashed, 1)  # default customer_id = 1
            )
            conn.commit()
            conn.close()
            flash("Registration successful! Please login.", "success")
            return redirect(url_for("login"))

        except sqlite3.IntegrityError:
            flash("Username already exists", "error")

    return render_template("register.html")

# -------------------- DASHBOARD -----------------------

@app.route("/dashboard")
@login_required
def dashboard():
    return render_template(
        "dashboard.html",
        username=session.get("username"),
        customer_id=session.get("customer_id"),
        chat_session_id=session.get("chat_session_id"),
    )

@app.route("/services")
@login_required
def services():
    return render_template(
        "services.html",
        username=session.get("username"),
        customer_id=session.get("customer_id"),
        chat_session_id=session.get("chat_session_id"),
    )

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# ===============================================================
# API ENDPOINTS FOR CHATBOT
# ===============================================================

# 1️⃣ STATIC DIRECT MESSAGE (Arun ticket example)
@app.route("/api/direct", methods=["POST"])
@login_required
def api_direct():

    customer_id = session.get("customer_id")
    if not customer_id:
        return jsonify({"has_special_message": False})

    msg = get_direct_response(customer_id)

    if msg:
        return jsonify({
            "has_special_message": True,
            "response": msg
        })

    return jsonify({"has_special_message": False})

# 2️⃣ FAQ LIST
@app.route("/api/faq-list", methods=["GET"])
@login_required
def api_faq_list():
    faqs = get_faq_list()
    return jsonify({"faqs": faqs})

# 3️⃣ PRE-FRAMED ANSWERS
@app.route("/api/preframed", methods=["POST"])
@login_required
def api_preframed():

    body = request.json or {}
    query_key = body.get("query_key")
    customer_id = session.get("customer_id")

    if not query_key:
        return jsonify({"error": "Missing query_key"}), 400

    answer = get_preframed_response(customer_id, query_key)
    return jsonify({"response": answer})

# 4️⃣ MAIN CHAT ENDPOINT → Goes to Orchestrator
@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():

    data = request.json or {}
    user_message = data.get("message")

    if not user_message:
        return jsonify({"error": "No message sent"}), 400

    # Retrieve or initialize chat history from session (as dicts)
    raw_history = session.get('chat_history', [])
    chat_history = []
    for msg in raw_history:
        if msg["type"] == "human":
            chat_history.append(HumanMessage(content=msg["content"]))
        elif msg["type"] == "ai":
            chat_history.append(AIMessage(content=msg["content"]))

    chat_history.append(HumanMessage(content=user_message))

    response = orchestrator_app.invoke({
        "messages": chat_history,
        "customer_id": session.get("customer_id")
    })

    bot_response = response["final_response"]
    print(f"Orchestrator: {response}")
    chat_history.append(AIMessage(content=bot_response))

    # Trim history if too long
    if len(chat_history) > 6:
        chat_history = chat_history[-2:]

    # Store as serializable dicts
    session['chat_history'] = [
        {"type": "human", "content": m.content} if isinstance(m, HumanMessage) else {"type": "ai", "content": m.content}
        for m in chat_history
    ]

    return jsonify({"response": response["final_response"]})

# ===============================================================
# START SERVER
# ===============================================================


if __name__ == "__main__":
    app.run(port=5000)
