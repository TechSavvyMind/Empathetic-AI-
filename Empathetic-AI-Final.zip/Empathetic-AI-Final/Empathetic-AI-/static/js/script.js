/**
 * ============================================================
 *    CHATBOT SYSTEM - script.js
 *    (Complete, commented, readable, and production-ready)
 * ============================================================
 *
 *  Major Sections:
 *    1. Global Variables / Constants
 *    2. Initialization Events
 *    3. Chat History Storage (sessionStorage)
 *    4. Rendering Messages (User/Bot)
 *    5. Typing Indicator
 *    6. Chat Window Controls (open, close, maximize)
 *    7. FAQ Button System
 *    8. Send Message → /api/chat
 *    9. Special Messages (Direct SQL-based alerts)
 *   10. Markdown Rendering Helper
 */

 
/* ============================================================
   1. GLOBAL STATE VARIABLES
   ============================================================ */

let isChatOpen = false;
let isMaximized = false;
let hasGreeted = false;

let chatHistory = [];

const SESSION_CHAT_KEY = "chatHistory:session";
// ------- Static FAQs (for Arun / demo) -------

const STATIC_FAQS = [
    {
        id: "kyc_status",
        label: "KYC Status",
        response: "Hi Arun, your KYC is already completed and verified ✅."
    },
    {
        id: "subscription_status",
        label: "Subscription Status",
        response: "Your current subscription is **ACTIVE** on the Gold Plan."
    },
    {
        id: "subscription_expiry",
        label: "Subscription Expiry",
        response: "Your subscription is valid till **31-Dec-2025**."
    },
    {
        id: "check_balance",
        label: "Check Balance",
        response: "Your current main balance is **₹299.00**."
    }
];

// Message when not logged in 
// add anchor link to login or Register in LOGIN_Prompt
function clearGuestLoginMessages() {
    // Remove any bot messages that contain login/register links
    const before = chatHistory.length;

    chatHistory = chatHistory.filter(msg => {
        if (msg.role !== "bot" || !msg.content) return true;
        // Any old guest login prompt will have /login or /register in it
        if (msg.content.includes("/login") || msg.content.includes("/register")) {
            return false;  // drop it
        }
        return true;
    });

    if (chatHistory.length !== before) {
        saveChatHistory();
    }
}

const LOGIN_PROMPT = `
I am happy to assist you!<br/>
But for security and account-specific queries, you need to be logged in.<br/>
Please <a href="/login">Login</a> or <a href="/register">Register</a> to continue.
`;


/* ============================================================
   2. INITIALIZATION (runs when page is loaded)
   ============================================================ */
document.addEventListener("DOMContentLoaded", function () {
    const userInput = document.getElementById("userInput");
    if (userInput) {
        userInput.addEventListener("keypress", function (e) {
            if (e.key === "Enter") sendMessage();
        });
    }

    if (isLoggedIn) {
        // 🔹 Logged in: restore chat + clean any old guest login prompts
        loadChatHistory();
        if (typeof clearGuestLoginMessages === "function") {
            clearGuestLoginMessages();
        }

        // If you have special ticket popup for Arun, keep this:
        checkForSpecialMessage();

    } else {
        // 🔹 NOT logged in: completely reset chat history
        try {
            sessionStorage.removeItem(SESSION_CHAT_KEY);
        } catch (e) {
            console.warn("Could not clear sessionStorage:", e);
        }
        chatHistory = [];

        // Show the guest popup ("Hi Guest 👋 ... Login/Register")
        const popupWrapper = document.querySelector(".popup-wrapper");
        const popup = document.getElementById("chatPopup");

        if (popupWrapper && popup) {
            popup.innerHTML = `
                Hi Guest 👋<br/>
                I'm your virtual assistant.<br/>
                Please <a href="/login">Login</a> or <a href="/register">Register</a>.
            `;
            popupWrapper.style.display = "block";
        }
    }

    console.log("✅ Chatbot initialized");
});



/* ============================================================
   3. CHAT HISTORY MANAGEMENT (sessionStorage)
   ============================================================ */

/**
 * Load chat history from sessionStorage
 */
function loadChatHistory() {
    try {
        const stored = sessionStorage.getItem(SESSION_CHAT_KEY);
        chatHistory = stored ? JSON.parse(stored) : [];
    } catch (e) {
        console.error("Chat history load error:", e);
        chatHistory = [];
    }
}

/**
 * Save chat history to sessionStorage
 */
function saveChatHistory() {
    try {
        sessionStorage.setItem(SESSION_CHAT_KEY, JSON.stringify(chatHistory));
    } catch (e) {
        console.error("Unable to save chat history:", e);
    }
}

/**
 * Re-renders all messages from chatHistory onto the UI
 */
function restoreChatUIFromHistory() {
    const chatBody = document.getElementById("chatBody");
    if (!chatBody) return;

    chatBody.innerHTML = "";

    chatHistory.forEach(msg => {
        const messageElement = document.createElement("div");
        messageElement.classList.add("message", msg.role === "user" ? "user-msg" : "bot-msg");

        if (msg.role === "bot") {
            messageElement.innerHTML = renderMarkdown(msg.content);
        } else {
            messageElement.innerText = msg.content;
        }

        chatBody.appendChild(messageElement);
    });

    chatBody.scrollTop = chatBody.scrollHeight;
}


/* ============================================================
   4. MESSAGE Rendering Helpers
   ============================================================ */

/**
 * Create a user message bubble
 */
function addUserMessage(text) {
    const chatBody = document.getElementById("chatBody");
    if (!chatBody) return;

    const msgDiv = document.createElement("div");
    msgDiv.className = "message user-msg";
    msgDiv.innerText = text;
    chatBody.appendChild(msgDiv);

    chatHistory.push({ role: "user", content: text });
    saveChatHistory();

    chatBody.scrollTop = chatBody.scrollHeight;
}

/**
 * Create a bot message bubble instantly
 */
function addBotMessageInstant(text) {
    const chatBody = document.getElementById("chatBody");
    if (!chatBody) return;

    const msgDiv = document.createElement("div");
    msgDiv.className = "message bot-msg";
    msgDiv.innerHTML = renderMarkdown(text);
    chatBody.appendChild(msgDiv);

    chatHistory.push({ role: "bot", content: text });
    saveChatHistory();

    chatBody.scrollTop = chatBody.scrollHeight;
}

/**
 * Typewriter effect for bot responses (word-by-word)
 */
async function typeBotMessageChunk(text) {
    const chatBody = document.getElementById("chatBody");
    if (!chatBody) return;

    const msgDiv = document.createElement("div");
    msgDiv.className = "message bot-msg";
    msgDiv.innerText = "";
    chatBody.appendChild(msgDiv);

    const words = text.split(" ");
    for (let i = 0; i < words.length; i++) {
        msgDiv.innerText += (i > 0 ? " " : "") + words[i];
        chatBody.scrollTop = chatBody.scrollHeight;
        await new Promise(res => setTimeout(res, 55));
    }

    msgDiv.innerHTML = renderMarkdown(msgDiv.innerText);

    chatHistory.push({ role: "bot", content: text });
    saveChatHistory();
}


/* ============================================================
   5. TYPING INDICATOR
   ============================================================ */

function showTypingIndicator() {
    const chatBody = document.getElementById("chatBody");
    if (!chatBody || document.getElementById("typingIndicator")) return;

    const indicator = document.createElement("div");
    indicator.id = "typingIndicator";
    indicator.className = "message typing-indicator";

    for (let i = 0; i < 3; i++) {
        let dot = document.createElement("div");
        dot.className = "typing-dot";
        indicator.appendChild(dot);
    }

    chatBody.appendChild(indicator);
    chatBody.scrollTop = chatBody.scrollHeight;
}

function hideTypingIndicator() {
    const indicator = document.getElementById("typingIndicator");
    if (indicator) indicator.remove();
}


/* ============================================================
   6. CHAT WINDOW CONTROLS
   ============================================================ */

/**
 * Toggle chat open/close
 */
function toggleChat() {
    const chatWindow = document.getElementById("chatWindow");

    isChatOpen = !isChatOpen;

    if (isChatOpen) {
        chatWindow.classList.add("active");
        restoreChatUIFromHistory();

        // Auto-greeting only ONCE per session
        if (chatHistory.length === 0 && !hasGreeted) {
            setTimeout(() => {
                if (isLoggedIn) {
                    addBotMessageInstant(`Hi ${currentUser}, how can I assist you today?`);
                    loadFAQButtons();
                } else {
                    addBotMessageInstant(LOGIN_PROMPT);
                }
                hasGreeted = true;
            }, 400);
        }
    } else {
        chatWindow.classList.remove("active");
    }
}

/**
 * Maximize/minimize chat
 */
function toggleMaximize(event) {
    event?.stopPropagation();

    const chatWindow = document.getElementById("chatWindow");
    const chatToggle = document.querySelector(".chat-toggle");
    const maximizeBtn = document.getElementById("maximizeBtn");

    isMaximized = !isMaximized;

    if (isMaximized) {
        chatWindow.classList.add("maximized");
        maximizeBtn.classList.replace("fa-expand-arrows-alt", "fa-compress-arrows-alt");
        chatToggle.style.display = "none";
    } else {
        chatWindow.classList.remove("maximized");
        maximizeBtn.classList.replace("fa-compress-arrows-alt", "fa-expand-arrows-alt");
        chatToggle.style.display = "flex";
    }
}

/**
 * Close chat (does NOT delete history)
 */
function closeChat(event) {
    event?.stopPropagation();

    const chatWindow = document.getElementById("chatWindow");
    const chatToggle = document.querySelector(".chat-toggle");

    chatWindow.classList.remove("active", "maximized");
    chatToggle.style.display = "flex";

    isChatOpen = false;
    isMaximized = false;
}


/* ============================================================
   7. FAQ BUTTON SYSTEM
   ============================================================ */

/**
 * Fetch FAQ buttons from backend
 */
function loadFAQButtons() {
    const faqContainer = document.getElementById("faqContainer");
    if (!faqContainer) return;

    faqContainer.innerHTML = `<div class="faq-label">📋 Quick Help for You:</div>`;

    STATIC_FAQS.forEach(faq => {
        const btn = document.createElement("button");
        btn.className = "faq-btn";
        btn.innerText = faq.label;
        btn.onclick = () => handleFAQClick(faq.id, faq.label);
        faqContainer.appendChild(btn);
    });
}


/**
 * Handle FAQ button click
 */
function handleFAQClick(queryKey, label) {
    const faq = STATIC_FAQS.find(f => f.id === queryKey);

    addUserMessage(label);
    showTypingIndicator();

    setTimeout(() => {
        hideTypingIndicator();
        if (faq) {
            addBotMessageInstant(faq.response);
        } else {
            addBotMessageInstant("Sorry, I don't have information for that right now.");
        }
    }, 500);
}


/* ============================================================
   8. SEND MESSAGE → /api/chat
   ============================================================ */

async function sendMessage() {
    const input = document.getElementById("userInput");
    const text = input.value.trim();

    if (!text) return;

    if (!isLoggedIn) {
        addUserMessage(text);
        addBotMessageInstant(LOGIN_PROMPT);
        input.value = "";
        return;
    }

    addUserMessage(text);
    input.value = "";

    showTypingIndicator();

    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: text })
        });

        hideTypingIndicator();

        const data = await response.json();

        if (data.response) {
            await typeBotMessageChunk(data.response);
        }

    } catch (error) {
        hideTypingIndicator();
        addBotMessageInstant("An error occurred. Please try again.");
    }
}


/* ============================================================
   9. SPECIAL MESSAGE CHECK (open ticket notifications)
   ============================================================ */

async function checkForSpecialMessage() {
    try {
        const response = await fetch("/api/direct", { method: "POST" });
        const data = await response.json();

        if (data.has_special_message) {
            // show bubble
            const popup = document.getElementById("chatPopup");
            popup.innerText = data.response;
            popup.style.display = "block";

            // show red badge
            const badge = document.querySelector(".notification-badge");
            badge.style.display = "flex";
        }
    } catch (error) {
        console.error("Special message error:", error);
    }
}


/* ============================================================
   10. BASIC MARKDOWN RENDERER (bold support)
   ============================================================ */

function renderMarkdown(text) {
    return text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
}

