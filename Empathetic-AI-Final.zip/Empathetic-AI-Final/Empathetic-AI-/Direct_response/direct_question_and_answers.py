# direct_question_and_answers.py
import os
import sqlite3
import yaml

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, "..", "TEAM_13.db")  # adjust if needed
QUESTIONS_RESPONSE_YAML = os.path.join(BASE_DIR, "questions_response.yaml")


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def load_questions_response_yaml():
    with open(QUESTIONS_RESPONSE_YAML, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_direct_response(customer_id: int) -> str | None:
    """
    Check if the given customer_id has a direct static response
    configured in questions_response.yaml.
    Used for things like:
      'Hi Arun, I see that a ticket is open for you...'
    """
    data = load_questions_response_yaml() or {}
    entry = data.get(str(customer_id))
    if not entry:
        return None

    sql_query = entry.get("sql")
    template = entry.get("response_template")

    if not sql_query or not template:
        return None

    conn = get_db_connection()
    try:
        cur = conn.cursor()
        try:
            cur.execute(sql_query, {"customer_id": customer_id})
        except TypeError:
            cur.execute(sql_query)
        row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        return None

    row_dict = dict(row)
    try:
        return template.format(**row_dict)
    except KeyError:
        return " ".join(f"{k}: {v}" for k, v in row_dict.items())
