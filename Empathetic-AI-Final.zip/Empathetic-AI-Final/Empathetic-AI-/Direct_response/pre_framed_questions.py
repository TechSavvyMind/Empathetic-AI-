# pre_framed_questions.py
import os
import sqlite3
import yaml

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, "..", "TEAM_13.db")  # adjust if needed
QUESTIONS_YAML = os.path.join(BASE_DIR, "questions.yaml")


def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def load_questions_yaml():
    with open(QUESTIONS_YAML, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_faq_list():
    """
    Returns list of FAQs for buttons.
    Each entry: {"id": query_key, "label": button_label}
    """
    data = load_questions_yaml() or {}
    faqs = []
    for key, value in data.items():
        label = value.get("button_label") or value.get("title") or key
        faqs.append({"id": key, "label": label})
    return faqs


def get_preframed_response(customer_id: int, query_key: str) -> str | None:
    """
    Given a customer_id and query_key from YAML,
    run the SQL and return formatted response text.
    """
    data = load_questions_yaml() or {}
    if query_key not in data:
        return None

    config = data[query_key]
    sql_query = config.get("sql")
    template = config.get("response_template")

    if not sql_query or not template:
        return None

    conn = get_db_connection()
    try:
        cur = conn.cursor()
        # pass customer_id as parameter if :customer_id used in SQL
        try:
            cur.execute(sql_query, {"customer_id": customer_id})
        except TypeError:
            # if SQL doesn't use named params
            cur.execute(sql_query)
        row = cur.fetchone()
    finally:
        conn.close()

    if not row:
        return "No data found for your account."

    data_dict = dict(row)
    try:
        return template.format(**data_dict)
    except KeyError:
        # Fallback to simple join of all values if template mismatch
        return " | ".join(f"{k}: {v}" for k, v in data_dict.items())
